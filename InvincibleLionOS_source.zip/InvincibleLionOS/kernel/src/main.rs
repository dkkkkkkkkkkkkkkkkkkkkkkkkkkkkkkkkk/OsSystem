#![no_main]
#![no_std]

use core::arch::asm;
use uefi::prelude::*;
use uefi::println;

/// COM1 serial output. Used so that QEMU can log boot status to a file.
fn serial_write(s: &str) {
    for b in s.bytes() {
        // SAFETY: port 0x3F8 is COM1 on x86; writing a byte is side-effect free
        // beyond emitting it on the serial line. We run in ring 0 under UEFI.
        unsafe {
            asm!("out dx, al", in("dx") 0x3F8u16, in("al") b,
                 options(nomem, nostack, preserves_flags));
        }
    }
}

#[entry]
fn main() -> Status {
    uefi::helpers::init().unwrap();
    serial_write("InvincibleLionOS 0.1 booted\r\n");
    println!("=== InvincibleLionOS 0.1 (Developer Preview) ===");
    println!("Boot OK. System halted (no further features yet).");
    loop {
        // SAFETY: hlt just idles the CPU until the next interrupt.
        unsafe { asm!("hlt", options(nomem, nostack)) };
    }
}
