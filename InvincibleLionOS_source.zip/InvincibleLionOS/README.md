# InvincibleLionOS 0.1 (Developer Preview)
UNTESTED source. First build happens on GitHub Actions.

1. Create a free GitHub account, make a new repository, upload ALL files from this folder (keep the .github folder).
2. Open the Actions tab -> wait for "build" to finish (green).
3. Open the run -> Artifacts -> download "InvincibleLionOS-exe" -> unzip -> InvincibleLionOS.exe.
4. Install QEMU for Windows (official: qemu.org), then run InvincibleLionOS.exe -> "Run in QEMU".

If a job is red, open it and send me the error text.
Known TODO: ISO output, own bootloader, code signing (SmartScreen may warn).
