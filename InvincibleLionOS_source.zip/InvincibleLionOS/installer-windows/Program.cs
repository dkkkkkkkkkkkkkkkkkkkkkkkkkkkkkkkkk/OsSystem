using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace InvincibleLionOS;

static class Program
{
    [STAThread]
    static void Main() { ApplicationConfiguration.Initialize(); Application.Run(new MainForm()); }
}

class MainForm : Form
{
    readonly TextBox log = new() { Multiline = true, ReadOnly = true, Dock = DockStyle.Fill,
        ScrollBars = ScrollBars.Vertical, BackColor = Color.FromArgb(12, 20, 40),
        ForeColor = Color.White, Font = new Font("Consolas", 10) };
    readonly string outDir = Path.Combine(Environment.GetFolderPath(
        Environment.SpecialFolder.LocalApplicationData), "InvincibleLionOS");

    public MainForm()
    {
        Text = "InvincibleLionOS 0.1 (Developer Preview)";
        Width = 760; Height = 520; BackColor = Color.FromArgb(12, 20, 40);
        var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(6) };
        bar.Controls.Add(Btn("Check environment", (_, _) => Check()));
        bar.Controls.Add(Btn("Run in QEMU", async (_, _) => await RunQemu()));
        bar.Controls.Add(Btn("Open output folder", (_, _) => { Directory.CreateDirectory(outDir); Process.Start("explorer.exe", outDir); }));
        Controls.Add(log); Controls.Add(bar);
        Log("InvincibleLionOS.exe is a helper: it launches the OS in a virtual machine.");
        Log("It does NOT touch your disks, partitions, bootloader or Secure Boot.");
        Check();
    }

    static Button Btn(string t, EventHandler h) { var b = new Button { Text = t, AutoSize = true }; b.Click += h; return b; }
    void Log(string s) { log.AppendText(s + Environment.NewLine); }

    static string? FindQemu()
    {
        foreach (var d in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        { try { var p = Path.Combine(d.Trim(), "qemu-system-x86_64.exe"); if (File.Exists(p)) return p; } catch { } }
        foreach (var root in new[] { Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                                     Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86) })
        { var p = Path.Combine(root, "qemu", "qemu-system-x86_64.exe"); if (File.Exists(p)) return p; }
        return null;
    }

    bool Check()
    {
        bool ok = true;
        Log($"OS: {RuntimeInformation.OSDescription}");
        if (RuntimeInformation.OSArchitecture != Architecture.X64)
        { Log("ERROR: only Windows 10/11 x64 is supported (ARM64 not in v0.1)."); ok = false; }
        var q = FindQemu();
        if (q == null)
        { Log("QEMU not found. Install it from https://www.qemu.org/download/#windows (official), then press Check again."); ok = false; }
        else
        {
            Log($"QEMU: {q}");
            if (!File.Exists(Path.Combine(Path.GetDirectoryName(q)!, "share", "edk2-x86_64-code.fd")))
            { Log("ERROR: UEFI firmware (share\\edk2-x86_64-code.fd) not found in QEMU folder."); ok = false; }
        }
        Log(ok ? "Environment OK." : "Environment NOT ready.");
        return ok;
    }

    async Task RunQemu()
    {
        if (!Check()) return;
        try
        {
            var q = FindQemu()!;
            var fw = Path.Combine(Path.GetDirectoryName(q)!, "share", "edk2-x86_64-code.fd");
            var esp = Path.Combine(outDir, "esp");
            var bootDir = Path.Combine(esp, "EFI", "BOOT");
            Directory.CreateDirectory(bootDir);
            var efi = Path.Combine(bootDir, "BOOTX64.EFI");
            using (var rs = Assembly.GetExecutingAssembly().GetManifestResourceStream("BOOTX64.EFI")
                   ?? throw new InvalidOperationException("Embedded kernel missing."))
            using (var fs = File.Create(efi)) rs.CopyTo(fs);
            Log("Kernel SHA-256: " + Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(efi))));
            var serial = Path.Combine(outDir, "serial.log");
            if (File.Exists(serial)) File.Delete(serial);

            var psi = new ProcessStartInfo(q) { UseShellExecute = false, CreateNoWindow = false };
            foreach (var a in new[] { "-machine", "q35", "-m", "256",
                "-drive", $"if=pflash,format=raw,readonly=on,file={fw}",
                "-drive", $"format=raw,file=fat:rw:{esp}",
                "-serial", $"file:{serial}", "-no-reboot" })
                psi.ArgumentList.Add(a);
            using var p = Process.Start(psi)!;
            Log("QEMU started. Waiting for boot message (up to 30 s)...");
            for (int i = 0; i < 30; i++)
            {
                await Task.Delay(1000);
                if (File.Exists(serial))
                {
                    string t; try { using var f = new FileStream(serial, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                                    using var r = new StreamReader(f); t = r.ReadToEnd(); } catch { continue; }
                    if (t.Contains("InvincibleLionOS 0.1 booted"))
                    { Log("SUCCESS: serial log contains 'InvincibleLionOS 0.1 booted'."); return; }
                }
            }
            Log("No boot message seen in 30 s. Check the QEMU window; boot may have failed.");
        }
        catch (Exception ex) { Log("ERROR: " + ex.Message); }
    }
}
